<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Transaction Cancel</title>
<style>
#footer {
    width: 100%;
    height: 90px;
    background: red;
    clear: both;
	margin-top:150px;
}
</style>

</head>
<body  style="background-color:indianred;">
	<h1 style="text-align:center; font-size:40px; margin-top:25%;">Your transaction has been canceled.</h1>
	<div id="footer">
     <h2 style="text-align:center;padding-top:30px;"> copyright &copy; 2010-20<?php echo  date("y");?> by Gourav Sharma </h2>        
    </div>

</body>
</html>